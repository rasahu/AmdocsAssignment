package example1;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Amdoc1{
boolean autoAck = false;
channel.basicConsume(queueName, autoAck, "a-consumer-tag", new DefaultConsumer(channel) {
    
    private final ObjectMappe objectMapper = new ObjectMapper();
    private final ExecutorService executorService = Executors.newFixedThreadPool(10); // thread pool for async processing
    
    @Override
    public void handleDelivery(String consumerTag, Envelope envelope, AMQP.BasicProperties properties, byte[] body) throws IOException {
        long deliveryTag = envelope.getDeliveryTag();
        String message = new String(body, "UTF-8");

        executorService.submit(() -> {
            try {
                // Deserialize message
                ApprovalRequestMessage approvalRequestMessage = objectMapper.readValue(message, ApprovalRequestMessage.class);
                
                // Fetch user and request data from repository
                Optional<User> userOpt = userRepository.getUser(approvalRequestMessage.getUserId());
                Optional<ApprovalRequest> approvalRequestOpt = approvalRequestRepository.getRequest(approvalRequestMessage.getRequestId());

                if (userOpt.isPresent() && approvalRequestOpt.isPresent()) {
                    User user = userOpt.get();
                    ApprovalRequest approvalRequest = approvalRequestOpt.get();

                    // Invoke rule engine to validate request
                    Evaluation evaluation = evaluateApprovalRequest(user.getCIF(), approvalRequest.getBoundaries());

                    // Handle evaluation result
                    if ("GREEN".equals(evaluation.status())) {
                        LOGGER.log(() -> "Request approved. Request ID: " + approvalRequestMessage.getRequestId());
                        channel.basicAck(deliveryTag, false);  // Acknowledge this single message
                    } else {
                        LOGGER.log(() -> "Request needs second evaluation. Request ID: " + approvalRequestMessage.getRequestId());
                        // Could store for further review or additional actions if needed
                    }
                } else {
                    LOGGER.log(() -> "User or ApprovalRequest not found for Request ID: " + approvalRequestMessage.getRequestId());
                }
            } catch (Exception e) {
                LOGGER.error("Technical issue while processing Request ID: " + approvalRequestMessage.getRequestId(), e);
                try {
                    channel.basicNack(deliveryTag, false, true);  // Retry the message later
                } catch (IOException ioException) {
                    LOGGER.error("Error during message nack", ioException);
                }
            }
        });
    }
});
}
